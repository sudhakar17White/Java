import java.util.*;
import java.io.*;
public class Main
{
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in); 
		
		DataInputStream input=new DataInputStream(System.in);
		
		
		
		try{
	
		int size,i=0;
		
		
		System.out.println("Enter the size of the array:");
		size=s.nextInt();
		
		
		String one[]=new String[size];
		
		String two[]=new String[size];
		
		System.out.println("Enter the names with initial(. sperate)");
		for(i=0;i<size;i++)
		{ 
		    
		    one[i]=input.readLine();
		    
		    
		}
		
		System.out.println("Enter initial names:");
		for(i=0;i<size;i++)
		{ 
		    
		    two[i]=input.readLine();
		    
		    
		}
		
		System.out.println("Name with initial array:");
		System.out.println(Arrays.toString(one));
		
		System.out.println("initial Name Array");
		System.out.println(Arrays.toString(two));
		
		
		String three[]=new String[size];
		
		
		String nam="";
		String initial="";
		String check="";
		
		for(i=0;i<size;i++)
		{ 
		    
		     
		     nam=one[i];
		    
		     
		     initial=""+nam.charAt(0);
		    
		     
		     for(int j=2;j<nam.length();j++)
		     { 
		         
		         char a=nam.charAt(j);
		         
		         check=check+a;
		         
		         for(int p=0;p<size;p++)
		         { 
		             
		            String fi=two[p];
		            
		            String fist=""+fi.charAt(0);
		            
		            if(fist.equals(initial))
		            {
		                String addname=two[p];
		                String add=addname+" "+check;
		                
		                three[p]=add;
		                
		            }
		             
		         }
		         
		         
		     }
		    check="";
		     
		    
		    
		}
		
		System.out.println("Answer :");
		 System.out.println(Arrays.toString(three));
		
		
		
		
		
		
		
		
		
		
		}
		catch(Exception e)
		{ 
		    
		    
		    
		}
		
		
	}
}

