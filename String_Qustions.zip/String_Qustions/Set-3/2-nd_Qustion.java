import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    
	    
	    Scanner s=new Scanner(System.in);
	    
	    
	    System.out.println("Enter the size of array:");
	    int size=s.nextInt();
	    
	    int number[]=new int[size];
	    
	    for(int i=0;i<size;i++)
	    { 
	        
	        number[i]=s.nextInt();
	        
	        
	    }
	    
	    System.out.println(Arrays.toString(number));
	   
	    int ans[]=new int[size];
	    
	    for(int i=0;i<size;i++)
	    { 
	         
	        if(i%2==1)
	        { 
	            
	         String even=String.valueOf(number[i]);
	         
	         char a=even.charAt(0);
	            
	         String con=""+a; 
	         
	         int val=Integer.parseInt(con);
	         
	         ans[i]=val;
	            
	        }
	        else
	        { 
	            
	         String even=String.valueOf(number[i]);
	         
	         int len=even.length()-1;
	         
	         char a=even.charAt(len);
	            
	         String con=""+a; 
	         
	         int val=Integer.parseInt(con);
	         
	         ans[i]=val;
	            
	            
	            
	        }
	        
	        
	        
	    }
	
	    System.out.println(Arrays.toString(ans));
	    
	    
	}
}
