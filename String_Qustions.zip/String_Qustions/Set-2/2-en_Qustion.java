import java.util.*;
public class Main
{
	public static void main(String[] args) {
		
		
		Scanner s=new Scanner(System.in);
		
		
		System.out.println("enter the word :");
		
		String word=s.nextLine();
		
		int len=word.length();
		String re="";
		int c=len;
		for(int i=0;i<len;i++)
		{ 
		    
		    c=c-1;
		    char a=word.charAt(c);
		    re=re+a;
		    
		   
		    
		    
		    
		}
		
		System.out.println(re);
		
		if(word.equals(re))
		{ 
		    
		    System.out.println("Yes, it is possible :)");
		    
		}
		else
		{ 
		    
		    
		    System.out.println("No, it is Not possible :(");
		    
		    
		}
		
	    
	}
}
